﻿using System;
using System.Text;

namespace DavidCodeTest
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                string input;
                int number;
                bool isValid;
                /*Print Instructions to User*/
                Console.WriteLine("\n***Integer limit 999999999***\n***Enter '0' to quit the program***\n");
                while (true)
                {
                    Console.Write("Enter integer : ");
                    input = Console.ReadLine();
                    isValid = int.TryParse(input, out number);
                    if (!isValid)
                        Console.WriteLine("\n  Not an integer, please try again\n");
                    else if (number > 999999999)
                        Console.WriteLine("\n Try with integer below the limit\n");
                    else if (number < 0)
                        Console.WriteLine("\n Try with integer greater than zero\n");
                    else if (number == 0)
                        Environment.Exit(0);
                    else
                        Console.WriteLine("\n  {0}\n", NumberToText(number));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
            }
        }

        public static string NumberToText(int number)
        {
            StringBuilder sb = new StringBuilder();
            try
            {
                int[] convertnum = new int[3];
                int first = 0;
                int ones, hundreds, tens;
                string[] words0 = { "", "One ", "Two ", "Three ", "Four ", "Five ", "Six ", "Seven ", "Eight ", "Nine " };
                string[] words1 = { "Ten ", "Eleven ", "Twelve ", "Thirteen ", "Fourteen ", "Fifteen ", "Sixteen ", "Seventeen ", "Eighteen ", "Nineteen " };
                string[] words2 = { "Twenty ", "Thirty ", "Forty ", "Fifty ", "Sixty ", "Seventy ", "Eighty ", "Ninety " };
                string[] words3 = { "Thousand ", "Million "};
                convertnum[0] = number % 1000;
                convertnum[1] = number / 1000;
                convertnum[2] = number / 1000000;
                convertnum[1] = convertnum[1] - 1000 * convertnum[2];

                //Considering loops faster than recursion I took this approach
                for (int i = 2; i > 0; i--)
                {
                    if (convertnum[i] != 0)
                    {
                        first = i;
                        break;
                    }
                }
                for (int i = first; i >= 0; i--)
                {
                    if (convertnum[i] == 0) continue;
                    ones = convertnum[i] % 10;
                    tens = convertnum[i] / 10;
                    hundreds = convertnum[i] / 100;
                    tens = tens - 10 * hundreds;
                    if (hundreds > 0) sb.Append(words0[hundreds] + "Hundred ");
                    if (ones > 0 || tens > 0)
                    {
                        if (hundreds > 0 || i < first) sb.Append("and ");
                        if (tens == 0)
                            sb.Append(words0[ones]);
                        else if (tens == 1)
                            sb.Append(words1[ones]);
                        else
                            sb.Append(words2[tens - 2] + words0[ones]);
                    }
                    if (i != 0) sb.Append(words3[i - 1]);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
            }
            return sb.ToString().TrimEnd();
        }
    }
}
